﻿In diesem Ordner liegen die geteilten Klassen.
Geteilt werden die Klassen zwischen dem Client (WebAssembly-Appp) und dem Backend.

Achtung: Die geteilten Klassen müssen nicht den Klassen entsprechen, die auch in der
Datenbank abgebildet werden. Darum nennt man diese auch Data Transfer Objects (DTOs).
Sie dienen daher dem Transfer zwischen zwei verteilten Systemen. Bei uns der Client- und der Server-App.

