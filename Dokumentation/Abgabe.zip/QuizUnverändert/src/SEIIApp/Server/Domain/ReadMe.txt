﻿In diesem Ordner liegen die Klassen, die 1:1 in der Datenbank abgebildet werden, bzw.
dazu verwendet werden in Berechnungslogiken verwendet zu werden, wobei wichtig ist,
dass diese Klassen selbst keine Logik enthalten. Sie dienen daher nur der
Repräsentation der abgebildeten Domäne aus einer rein strukturellen Sicht.

